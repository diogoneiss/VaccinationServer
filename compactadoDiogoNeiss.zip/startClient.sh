#!/bin/bash
./cliente 127.0.0.1 51513