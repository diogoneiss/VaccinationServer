#!/bin/bash
gcc -g -Wall servidor.c common.o -o servidor && ./servidor v4 51513